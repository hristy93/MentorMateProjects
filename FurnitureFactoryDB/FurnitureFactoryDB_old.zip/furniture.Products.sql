﻿IF NOT EXISTS (
	SELECT * FROM sys.objects 
	WHERE object_id = OBJECT_ID(N'[furniture].[Products]') AND type = 'U'
)
BEGIN
	CREATE TABLE [furniture].[Products]
	(
		[Id] INT NOT NULL IDENTITY PRIMARY KEY, 
		[Name] NVARCHAR(120) NOT NULL, 
		[Description] NVARCHAR(250) NULL, 
		[Weight] DECIMAL(7,3) NOT NULL, 
		[BarcodeNumber] NVARCHAR(13) NOT NULL UNIQUE, 
		[Price] MONEY NOT NULL,
		INDEX IX_Name NONCLUSTERED ([Name]),
		INDEX IX_BarcodeNumber NONCLUSTERED ([BarcodeNumber])
	)
END;

-- Добавяне на нови записи
DECLARE @Name NVARCHAR(120)
DECLARE @Description NVARCHAR(250);
DECLARE @Weight DECIMAL(7,3);
DECLARE @BarcodeNumber NVARCHAR(13); 
DECLARE @Price MONEY;
SET @Name = N'Маса #271 IKEA ООД';
SET @Description = N'Кръгла бяла маса с 4 крака предлаган в магазин IKEA';
SET @Weight = 12.4;
SET @BarcodeNumber =  N'1441170443635';
SET @Price = 21.90;
INSERT INTO furniture.Products
VALUES (@Name, @Description, @Weight, @BarcodeNumber, @Price)

-- Добавяне на index на колона
CREATE NONCLUSTERED INDEX IX_BarcodeNumber ON [furniture].[Products]([BarcodeNumber])

-- Добавяне на unique key на колона
ALTER TABLE furniture.Products
ADD UNIQUE ([BarcodeNumber])

-- Добавяне на primary key на колона
ALTER TABLE [furniture].[Products]
ADD PRIMARY KEY ([Name]);

-- Показване на всички записи
SELECT *
FROM [furniture].[Products]

-- Промяна на стойност на даден запис по зададено Id
DECLARE @ProductId INT;
DECLARE @NewValue money;
DECLARE @ColumnToUpdate NVARCHAR(50);
SET @ProductId = 29;
SET @NewValue = N'88.90';
SET @ColumnToUpdate = N'Price';
UPDATE [furniture].[Products]
SET [Price] = @NewValue
WHERE [Id] = @ProductId;

-- Промяна на колона 
ALTER TABLE [furniture].[Products]
ALTER COLUMN [Name] NVARCHAR(120) NOT NULL;

-- Изтриване запис по Id
DECLARE @ProductId INT;
SET @ProductId = 29;
DELETE FROM [furniture].[Products]
WHERE [Id] = @ProductId;

-- Изтриване на таблицата
DROP TABLE [furniture].[Products];

-- Изтриване на index
DROP INDEX IX_Name;

-- Изтриване на constraint
ALTER TABLE [furniture].[Products]
DROP CONSTRAINT UQ__Products__DF352225CD365481;

-- Създаване на лог за промяната на продуктите
CREATE TRIGGER LogProductUpdateOrInsert ON [furniture].[Products]
AFTER UPDATE, INSERT
AS
BEGIN
	--IF @@rowcount = 0 
	--	RETURN
	SET NOCOUNT ON
	--IF	EXISTS (SELECT * FROM inserted) AND 
	--	EXISTS (SELECT * FROM deleted)
	--BEGIN

		--DECLARE @ProductChangeInfo TABLE(
		--	[Date] SMALLDATETIME NOT NULL, 
		--	[OldValue] NVARCHAR(250) NOT NULL, 
		--	[OldValue] NVARCHAR(250) NOT NULL
		--);

		--SET @ProductChangeInfo = (
		--	SELECT [Date], [OldValue], [OldValue]
		--	FROM inserted AS I JOIN [furniture].[Products] AS P ON I.Id = P.Id
		--					   JOIN deleted AS D ON D.Id = P.Id 
		--);

		--IF UPDATE([Id])
		--	BEGIN
		--	INSERT INTO [furniture].[ProductsChangeLog]
		--	SELECT convert(smalldatetime, getdate()), 'Column',  OP.[Name] AS 'OldValue', NP.[Name] AS 'NewValue', SUSER_SNAME()
		--	FROM inserted AS I LEFT OUTER JOIN deleted AS D ON I.[Id] = D.[Id] AND I.[Name] <> D.[Name]
		--					   LEFT OUTER JOIN [furniture].[Products] OP ON OP.[Id] = D.[Id]
		--					   INNER JOIN [furniture].[Products] NP ON NP.[Id] = I.[Id]	
		--    END;

		IF UPDATE([Name])
			BEGIN
			INSERT INTO [furniture].[ProductsChangeLog]
			SELECT convert(smalldatetime, CURRENT_TIMESTAMP), I.Id AS 'ProductID', 'Name',  D.[Name] AS 'OldName', I.[Name] AS 'NewName', SUSER_SNAME()
			FROM inserted AS I LEFT OUTER JOIN deleted AS D ON I.[Id] = D.[Id] AND I.[Name] <> D.[Name]
			--FROM inserted AS I LEFT OUTER JOIN deleted AS D ON I.[Id] = D.[Id] AND I.[Name] <> D.[Name]
			--				   LEFT OUTER JOIN [furniture].[Products] OP ON OP.[Name] = D.[Name]
			--				   INNER JOIN [furniture].[Products] NP ON NP.[Name] = I.[Name]		
		    END;	

		IF UPDATE([Description])
			BEGIN
			INSERT INTO [furniture].[ProductsChangeLog]
			SELECT CONVERT(smalldatetime, CURRENT_TIMESTAMP), I.Id AS 'ProductID', 'Description', D.[Description] AS 'OldDescription', I.[Description] AS 'NewDescription', SUSER_SNAME()
			FROM inserted AS I LEFT OUTER JOIN deleted AS D ON I.[Id] = D.[Id] AND I.[Description] <> D.[Description]	
		    END;	
				
		IF UPDATE([Weight])
			BEGIN
			INSERT INTO [furniture].[ProductsChangeLog]
			SELECT CONVERT(smalldatetime, CURRENT_TIMESTAMP), I.Id AS 'ProductID', 'Weight', CONVERT(NVARCHAR, D.[Weight]) AS 'OldWeight', CONVERT(NVARCHAR, I.[Weight]) AS 'NewWeight', SUSER_SNAME()
			FROM inserted AS I LEFT OUTER JOIN deleted AS D ON I.[Id] = D.[Id] AND I.[Weight] <> D.[Weight]	
		    END;	
			
		IF UPDATE([BarcodeNumber])
			BEGIN
			INSERT INTO [furniture].[ProductsChangeLog]
			SELECT CONVERT(smalldatetime, CURRENT_TIMESTAMP), I.Id AS 'ProductID', 'BarcodeNumber', D.[BarcodeNumber] AS 'OldDescription', I.[BarcodeNumber] AS 'NewDescription', SUSER_SNAME()
			FROM inserted AS I LEFT OUTER JOIN deleted AS D ON I.[Id] = D.[Id] AND I.[BarcodeNumber] <> D.[BarcodeNumber]
		    END;	
			
		IF UPDATE([Price])
			BEGIN
			INSERT INTO [furniture].[ProductsChangeLog]
			SELECT CONVERT(smalldatetime, CURRENT_TIMESTAMP), I.Id AS 'ProductID', 'Price', CONVERT(NVARCHAR, D.[Price]) AS 'OldWeight', CONVERT(NVARCHAR, I.[Price]) AS 'NewWeight', SUSER_SNAME()
			FROM inserted AS I LEFT OUTER JOIN deleted AS D ON I.[Id] = D.[Id] AND I.[Price] <> D.[Price]	
		    END;	   
	--END;
END;

--DROP TRIGGER LogProductChange;

CREATE TRIGGER LogProductDelete ON [furniture].[Products]
AFTER DELETE
AS
BEGIN
	--IF @@rowcount = 0 
	--	RETURN
	SET NOCOUNT ON;

	INSERT INTO [furniture].[ProductsChangeLog]
	SELECT CONVERT(smalldatetime, CURRENT_TIMESTAMP), D.Id AS 'ProductID', 'Name', D.[Name] AS 'OldValue', NULL AS 'NewValue', SUSER_SNAME()
	FROM deleted AS D

	INSERT INTO [furniture].[ProductsChangeLog]
	SELECT CONVERT(smalldatetime, CURRENT_TIMESTAMP), D.Id AS 'ProductID', 'Description', D.[Description] AS 'OldValue', NULL AS 'NewValue', SUSER_SNAME()
	FROM deleted AS D --[Products] AS P RIGHT OUTER JOIN deleted AS D ON D.[Id] = P.[Id] AND P.[Description] <> D.[Description]

	INSERT INTO [furniture].[ProductsChangeLog]
	SELECT CONVERT(smalldatetime, CURRENT_TIMESTAMP), D.Id AS 'ProductID', 'Weight', D.[Weight] AS 'OldValue', NULL AS 'NewValue', SUSER_SNAME()
	FROM deleted AS D --[Products] AS P RIGHT OUTER JOIN deleted AS D ON D.[Id] = P.[Id] AND P.[Weight] <> D.[Weight]

	INSERT INTO [furniture].[ProductsChangeLog]
	SELECT CONVERT(smalldatetime, CURRENT_TIMESTAMP), D.Id AS 'ProductID', 'BarcodeNumber', D.[BarcodeNumber] AS 'OldValue', NULL AS 'NewValue', SUSER_SNAME()
	FROM deleted AS D --[Products] AS P RIGHT OUTER JOIN deleted AS D ON D.[Id] = P.[Id] AND P.[Weight] <> D.[Weight]

	INSERT INTO [furniture].[ProductsChangeLog]
	SELECT CONVERT(smalldatetime, CURRENT_TIMESTAMP), D.Id AS 'ProductID', 'Price', D.[Price] AS 'OldValue', NULL AS 'NewValue', SUSER_SNAME()
	FROM deleted AS D --[Products] AS P RIGHT OUTER JOIN deleted AS D ON D.[Id] = P.[Id] AND P.[Price] <> D.[Price]		  
END;

SELECT * FROM [furniture].[ProductsChangeLog];